
public class StackUnderflowException extends Exception {
	public StackUnderflowException() 
	{
		
	}
	
	public StackUnderflowException(String msg) 
	{
		super(msg);
	}
}
